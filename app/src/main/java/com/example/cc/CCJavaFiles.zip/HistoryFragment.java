package com.example.cc;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HistoryFragment extends Fragment {

    private LinearLayout layoutHistory;
    private DatabaseHelper dbHelper;

    public HistoryFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);
        layoutHistory = view.findViewById(R.id.layoutHistory);
        dbHelper = new DatabaseHelper(getContext());

        loadBookingHistory();
        return view;
    }

    private void loadBookingHistory() {
        layoutHistory.removeAllViews();

        int userId = SessionManager.getUserId(getContext());
        Cursor cursor = dbHelper.getBookingsByUserId(userId);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String className = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.BOOKING_CLASS_NAME));
                String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.BOOKING_CLASS_TIME));
                String category = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.BOOKING_CLASS_CATEGORY));

                TextView historyItem = new TextView(getContext());
                historyItem.setText("• " + className + "\n   Category: " + category + "\n   Time: " + time);
                historyItem.setTextSize(15);
                historyItem.setPadding(16, 12, 16, 12);
                historyItem.setBackgroundResource(R.drawable.booking_card_background);
                historyItem.setTextColor(getResources().getColor(android.R.color.black));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 0, 0, 16);
                historyItem.setLayoutParams(params);

                layoutHistory.addView(historyItem);
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            TextView empty = new TextView(getContext());
            empty.setText("No bookings found.");
            layoutHistory.addView(empty);
        }
    }
}

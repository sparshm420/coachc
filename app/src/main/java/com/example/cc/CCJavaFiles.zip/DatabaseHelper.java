package com.example.cc;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "CoachConnect.db";
    private static final int DATABASE_VERSION = 5; // Bump this to reset schema

    // User Table
    public static final String TABLE_USER = "users";
    public static final String TABLE_ADMINS = "admins";
    public static final String TABLE_COACHES = "coaches";
    public static final String TABLE_LEARNERS = "learners";
    public static final String USER_ID = "id";
    public static final String USER_NAME = "name";
    public static final String USER_EMAIL = "email";
    public static final String USER_PASSWORD = "password";
    public static final String USER_PREFERENCES = "preferences";

    // Booking Table
    public static final String TABLE_BOOKING = "bookings";
    public static final String BOOKING_ID = "id";
    public static final String BOOKING_CLASS_NAME = "class_name";
    public static final String BOOKING_CLASS_TIME = "class_time";
    public static final String BOOKING_CLASS_CATEGORY = "class_category";
    public static final String BOOKING_USER_ID = "user_id";
    public static final String USER_PHONE = "phone";
    public static final String USER_AVATAR = "avatar";


    // Class Table
    public static final String TABLE_CLASS = "classes";
    public static final String CLASS_ID = "id";
    public static final String CLASS_NAME = "name";
    public static final String CLASS_CATEGORY = "category";
    public static final String CLASS_TIME = "time";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Drop old tables (safe guard)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKING);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLASS);

        // Create users table
        db.execSQL("CREATE TABLE " + TABLE_USER + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_NAME + " TEXT, " +
                USER_EMAIL + " TEXT UNIQUE, " +
                USER_PASSWORD + " TEXT, " +
                USER_PREFERENCES + " TEXT, " +
                USER_PHONE + " TEXT, " +
                USER_AVATAR + " BLOB)"); // remove NOT NULL;


        // Create bookings table
        db.execSQL("CREATE TABLE " + TABLE_BOOKING + " (" +
                BOOKING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                BOOKING_CLASS_NAME + " TEXT, " +
                BOOKING_CLASS_TIME + " TEXT, " +
                BOOKING_CLASS_CATEGORY + " TEXT, " +
                BOOKING_USER_ID + " INTEGER)");

        // Create classes table
        db.execSQL("CREATE TABLE " + TABLE_CLASS + " (" +
                CLASS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CLASS_NAME + " TEXT, " +
                CLASS_CATEGORY + " TEXT, " +
                CLASS_TIME + " TEXT)");

        db.execSQL("CREATE TABLE reviews (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "class_name TEXT, " +
                "rating INTEGER, " +
                "comment TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_ADMINS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_COACHES + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_LEARNERS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password TEXT)");
        // Sample classes
        db.execSQL("INSERT INTO " + TABLE_CLASS + " (name, category, time) VALUES ('Zenith Yoga Studio', 'Yoga', '08:00 AM')");
        db.execSQL("INSERT INTO " + TABLE_CLASS + " (name, category, time) VALUES ('Aqua Splash Pool', 'Swimming', '10:30 AM')");
        db.execSQL("INSERT INTO " + TABLE_CLASS + " (name, category, time) VALUES ('FitKick Football Arena', 'Football', '05:00 PM')");
        db.execSQL("INSERT INTO " + TABLE_CLASS + " (name, category, time) VALUES ('Cricket Pro Academy', 'Cricket', '03:00 PM')");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS reviews");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKING);
        // Rebuild schema
        onCreate(db);
    }

    // Register user
    public boolean registerUser(String name, String email, String password, String preferences, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_NAME, name);
        values.put(USER_EMAIL, email);
        values.put(USER_PASSWORD, password);
        values.put(USER_PREFERENCES, preferences);
        values.put(USER_PHONE, phone);

        long result = db.insert(TABLE_USER, null, values);
        return result != -1;
    }

    public boolean registerAdmin(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("password", password);
        long result = db.insert(TABLE_ADMINS, null, values);
        return result != -1;
    }

    public boolean registerCoach(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("password", password);
        long result = db.insert(TABLE_COACHES, null, values);
        return result != -1;
    }

    public boolean registerLearner(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("password", password);
        long result = db.insert(TABLE_LEARNERS, null, values);
        return result != -1;
    }

    // Validate login
    public Cursor validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USER +
                " WHERE " + USER_EMAIL + " = ? AND " + USER_PASSWORD + " = ?", new String[]{email, password});
    }

    public Cursor getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USER + " WHERE " + USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    public Cursor getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USER + " WHERE " + USER_EMAIL + " = ?", new String[]{email});
    }

    // Insert class (manually if needed)
    public boolean insertClass(String name, String category, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CLASS_NAME, name);
        values.put(CLASS_CATEGORY, category);
        values.put(CLASS_TIME, time);
        long result = db.insert(TABLE_CLASS, null, values);
        return result != -1;
    }

    // Get all classes
    public List<String> getAllClasses(String category) {
        List<String> classList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;

        if (category == null || category.isEmpty()) {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_CLASS, null);
        } else {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_CLASS + " WHERE " + CLASS_CATEGORY + " = ?", new String[]{category});
        }

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(CLASS_NAME));
                String cat = cursor.getString(cursor.getColumnIndexOrThrow(CLASS_CATEGORY));
                classList.add(name + " (" + cat + ")");
            } while (cursor.moveToNext());
        }

        cursor.close();
        return classList;
    }

    // Get class by name
    public Cursor getClassByName(String className) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_CLASS + " WHERE " + CLASS_NAME + " = ?", new String[]{className});
    }

    // Add booking
    public boolean addBooking(int userId, String className, String classTime, String classCategory) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(BOOKING_USER_ID, userId);
        values.put(BOOKING_CLASS_NAME, className);
        values.put(BOOKING_CLASS_TIME, classTime);
        values.put(BOOKING_CLASS_CATEGORY, classCategory);
        long result = db.insert(TABLE_BOOKING, null, values);
        return result != -1;
    }

    // Get bookings by user ID
    public Cursor getBookingsByUserId(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_BOOKING + " WHERE " + BOOKING_USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    // Delete booking
    public boolean deleteBooking(int bookingId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_BOOKING, BOOKING_ID + " = ?", new String[]{String.valueOf(bookingId)});
        return result > 0;
    }

    public boolean insertReview(int userId, String className, int rating, String comment) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("class_name", className);
        values.put("rating", rating);
        values.put("comment", comment);
        long result = db.insert("reviews", null, values);
        return result != -1;
    }

    // Get average rating for class
    public float getAverageRating(String className) {
        SQLiteDatabase db = this.getReadableDatabase();
        float avg = 0;

        try {
            Cursor cursor = db.rawQuery("SELECT AVG(rating) as avg_rating FROM reviews WHERE class_name = ?", new String[]{className});
            if (cursor.moveToFirst() && !cursor.isNull(0)) {
                avg = cursor.getFloat(cursor.getColumnIndexOrThrow("avg_rating"));
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace(); // helpful during dev
        }

        return avg;
    }

    public List<String> getReviewsForClass(String className) {
        List<String> reviews = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT rating, comment FROM reviews WHERE class_name = ?", new String[]{className});

        if (cursor.moveToFirst()) {
            do {
                int rating = cursor.getInt(cursor.getColumnIndexOrThrow("rating"));
                String comment = cursor.getString(cursor.getColumnIndexOrThrow("comment"));

                String display = "★" + rating + (comment != null && !comment.isEmpty() ? " - " + comment : "");
                reviews.add(display);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return reviews;
    }

    public boolean hasUserReviewedClass(int userId, String className) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM reviews WHERE user_id = ? AND class_name = ?", new String[]{
                String.valueOf(userId), className
        });

        boolean hasReviewed = cursor.getCount() > 0;
        cursor.close();
        return hasReviewed;
    }

    public List<String> getTopRatedClasses(int limit) {
        List<String> topClasses = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT class_name, AVG(rating) as avg_rating " +
                "FROM reviews GROUP BY class_name ORDER BY avg_rating DESC LIMIT ?", new String[]{String.valueOf(limit)});

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("class_name"));
                float rating = cursor.getFloat(cursor.getColumnIndexOrThrow("avg_rating"));

                // Get category from class table
                Cursor classCursor = db.rawQuery("SELECT category FROM classes WHERE name = ?", new String[]{name});
                String category = classCursor.moveToFirst()
                        ? classCursor.getString(classCursor.getColumnIndexOrThrow("category"))
                        : "Unknown";

                classCursor.close();

                topClasses.add(name + " (" + category + ") ★" + String.format("%.1f", rating));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return topClasses;
    }

    public boolean updateUserProfile(int userId, String name, String email, String phone, String avatarUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_NAME, name);
        values.put(USER_EMAIL, email);
        values.put(USER_PHONE, phone);
        values.put(USER_AVATAR, avatarUri);

        int rows = db.update(TABLE_USER, values, USER_ID + " = ?", new String[]{String.valueOf(userId)});
        return rows > 0;
    }



}

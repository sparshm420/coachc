package com.example.cc;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.util.List;

public class HomeFragment extends Fragment {

    DatabaseHelper dbHelper;
    LinearLayout layoutUpcoming;

    TextView txtWelcome, txtUpcoming, txtPopular;
    LinearLayout layoutPopular;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        int userId = SessionManager.getUserId(getContext());
        if (userId == -1) {
            Toast.makeText(getContext(), "Session expired. Please log in.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        txtWelcome = view.findViewById(R.id.txtWelcome);
        txtPopular = view.findViewById(R.id.txtPopular);
        layoutPopular = view.findViewById(R.id.layoutPopular);
        layoutUpcoming = view.findViewById(R.id.layoutUpcoming);

        Button btnSearch = view.findViewById(R.id.btnSearch);
        Button btnBookings = view.findViewById(R.id.btnBookings);
        Button btnProfile = view.findViewById(R.id.btnProfile);

        dbHelper = new DatabaseHelper(getContext());

        loadUserName();
        loadUpcomingBookings();

        TextView topRatedTitle = new TextView(getContext());
        topRatedTitle.setText("Top Rated Classes");
        topRatedTitle.setTextSize(18);
        topRatedTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        topRatedTitle.setPadding(0, 32, 0, 16);


        loadPopularClasses();

        // Navigation buttons
        btnSearch.setOnClickListener(v -> navigateTo(new SearchFragment()));
        btnBookings.setOnClickListener(v -> navigateTo(new BookingsFragment()));
        btnProfile.setOnClickListener(v -> navigateTo(new ProfileFragment()));

        return view;
    }

    private void loadUserName() {
        int userId = SessionManager.getUserId(getContext());
        Cursor cursor = dbHelper.getUserById(userId);
        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.USER_NAME));
            txtWelcome.setText("Welcome, " + name + "!");
            cursor.close();
        }
    }

    private void loadUpcomingBookings() {
        layoutUpcoming.removeAllViews();

        int userId = SessionManager.getUserId(getContext());
        Cursor cursor = dbHelper.getBookingsByUserId(userId);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                // If there are bookings, show them and nothing else
                do {
                    String className = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.BOOKING_CLASS_NAME));
                    String classTime = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.BOOKING_CLASS_TIME));

                    TextView bookingText = new TextView(getContext());
                    bookingText.setText("• " + className + " at " + classTime);
                    bookingText.setTextSize(14);
                    bookingText.setPadding(8, 4, 8, 4);

                    layoutUpcoming.addView(bookingText);

                } while (cursor.moveToNext());
            } else {
                // Only show this message if there are no bookings
                TextView noBooking = new TextView(getContext());
                noBooking.setText("You have no upcoming bookings.");
                noBooking.setTextSize(14);
                noBooking.setPadding(8, 8, 8, 8);
                layoutUpcoming.addView(noBooking);
            }
            cursor.close();
        }
    }





    private void loadPopularClasses() {
        layoutPopular.removeAllViews();

        List<String> topRated = dbHelper.getTopRatedClasses(3); // Top 3 classes from real reviews

        if (topRated.isEmpty()) {
            TextView none = new TextView(getContext());
            none.setText("No reviews yet.");
            none.setPadding(8, 8, 8, 8);
            layoutPopular.addView(none);
        } else {
            for (String item : topRated) {
                TextView classText = new TextView(getContext());
                classText.setText("• " + item);
                classText.setTextSize(15);
                classText.setPadding(16, 12, 16, 12);
                classText.setBackgroundResource(R.drawable.booking_card_background);
                classText.setTextColor(getResources().getColor(android.R.color.black));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 0, 0, 16);
                classText.setLayoutParams(params);

                layoutPopular.addView(classText);
            }
        }
    }


    private void navigateTo(Fragment fragment) {
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainer, fragment);
        transaction.commit();
    }
}

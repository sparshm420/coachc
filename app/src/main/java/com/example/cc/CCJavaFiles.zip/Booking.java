package com.example.cc;

public class Booking {
    public int id;
    public String className;
    public String time;
    public String category;

    public Booking(int id, String className, String time, String category) {
        this.id = id;
        this.className = className;
        this.time = time;
        this.category = category;
    }
}

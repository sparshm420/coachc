package com.example.cc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    DatabaseHelper dbHelper;
    TextView tvWelcome, tvEmail, tvPreferences, tvBookingCount;
    EditText edtName, edtEmail, edtPhone;
    ImageView imgAvatar;
    Uri selectedImageUri = null;
    int userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        userId = SessionManager.getUserId(getContext());
        if (userId == -1) {
            Toast.makeText(getContext(), "Session expired. Please log in.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }

        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        dbHelper = new DatabaseHelper(getContext());

        // UI references
        tvWelcome = view.findViewById(R.id.tvWelcome);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvPreferences = view.findViewById(R.id.tvPreferences);
        tvBookingCount = view.findViewById(R.id.tvBookingCount);

        edtName = view.findViewById(R.id.edtName);
        edtEmail = view.findViewById(R.id.edtEmail);
        edtPhone = view.findViewById(R.id.edtPhone);
        imgAvatar = view.findViewById(R.id.imgAvatar);

        Button btnChangeAvatar = view.findViewById(R.id.btnChangeAvatar);
        Button btnSave = view.findViewById(R.id.btnSave);
        Button btnLogout = view.findViewById(R.id.btnLogout);

        // Avatar picker
        btnChangeAvatar.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        // Save changes
        btnSave.setOnClickListener(v -> saveProfileChanges());

        // Logout
        btnLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(getContext())
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to log out?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        SessionManager.logout(getContext());
                        Intent intent = new Intent(getContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        loadUserProfile();

        return view;
    }

    private void loadUserProfile() {
        Cursor userCursor = dbHelper.getUserById(userId);
        if (userCursor != null && userCursor.moveToFirst()) {
            String name = userCursor.getString(userCursor.getColumnIndexOrThrow(DatabaseHelper.USER_NAME));
            String email = userCursor.getString(userCursor.getColumnIndexOrThrow(DatabaseHelper.USER_EMAIL));
            String preferences = userCursor.getString(userCursor.getColumnIndexOrThrow(DatabaseHelper.USER_PREFERENCES));
            String phone = userCursor.getString(userCursor.getColumnIndexOrThrow(DatabaseHelper.USER_PHONE));
            String avatarUri = userCursor.getString(userCursor.getColumnIndexOrThrow(DatabaseHelper.USER_AVATAR));

            tvWelcome.setText("Welcome, " + name + "!");
            tvEmail.setText("Email: " + email);
            tvPreferences.setText("Preferences: " + preferences);
            edtName.setText(name);
            edtEmail.setText(email);
            edtPhone.setText(phone);

            if (avatarUri != null && !avatarUri.isEmpty()) {
                imgAvatar.setImageURI(Uri.parse(avatarUri));
            }

            userCursor.close();
        }

        Cursor bookingCursor = dbHelper.getBookingsByUserId(userId);
        int count = (bookingCursor != null) ? bookingCursor.getCount() : 0;
        tvBookingCount.setText("Bookings Made: " + count);
        if (bookingCursor != null) bookingCursor.close();
    }

    private void saveProfileChanges() {
        String name = edtName.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();
        String avatarUriStr = (selectedImageUri != null) ? selectedImageUri.toString() : null;

        boolean updated = dbHelper.updateUserProfile(userId, name, email, phone, avatarUriStr);

        if (updated) {
            Toast.makeText(getContext(), "Profile updated successfully", Toast.LENGTH_SHORT).show();
            loadUserProfile();
        } else {
            Toast.makeText(getContext(), "Failed to update profile", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            imgAvatar.setImageURI(selectedImageUri);
        }
    }
}

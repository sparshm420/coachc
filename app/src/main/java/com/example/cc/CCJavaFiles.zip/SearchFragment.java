package com.example.cc;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {

    private ListView classListView;
    private ArrayAdapter<String> classAdapter;
    private List<String> classList;
    private DatabaseHelper dbHelper;
    private LinearLayout layoutFilters;

    public SearchFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        int userId = SessionManager.getUserId(getContext());
        if (userId == -1) {
            Toast.makeText(getContext(), "Session expired. Please log in.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        classListView = view.findViewById(R.id.classListView);
        layoutFilters = view.findViewById(R.id.layoutFilters);

        dbHelper = new DatabaseHelper(getContext());
        classList = new ArrayList<>();

        classAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, classList);
        classListView.setAdapter(classAdapter);

        loadAllClasses();
        setupFilterButtons();

        classListView.setOnItemClickListener((parent, view1, position, id) -> {
            String selectedItem = classList.get(position);

            new AlertDialog.Builder(getContext())
                    .setTitle("Book Class")
                    .setMessage("Do you want to book this class?\n\n" + selectedItem)
                    .setPositiveButton("Yes", (dialog, which) -> bookClass(selectedItem))
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        classListView.setOnItemLongClickListener((parent, view1, position, id) -> {
            String selectedItem = classList.get(position);
            String className = selectedItem.split(" \\(")[0].split("★")[0].trim();

            showReviewsDialog(className);
            return true;
        });


        return view;
    }

    private void loadAllClasses() {
        classList.clear();
        List<String> all = dbHelper.getAllClasses(""); // No filter
        for (String className : all) {
            String cleanName = className.split(" \\(")[0].trim(); // e.g., "Zenith Yoga Studio"
            float rating = dbHelper.getAverageRating(cleanName);
            String stars = (rating > 0) ? " ★" + String.format("%.1f", rating) : " ★New";
            classList.add(className + stars);
        }
        classAdapter.notifyDataSetChanged();
    }

    private void filterClasses(String category) {
        classList.clear();
        List<String> filtered = dbHelper.getAllClasses(category);
        for (String className : filtered) {
            String cleanName = className.split(" \\(")[0].trim();
            float rating = dbHelper.getAverageRating(cleanName);
            String stars = (rating > 0) ? " ★" + String.format("%.1f", rating) : " ★New";
            classList.add(className + stars);
        }
        classAdapter.notifyDataSetChanged();
    }

    private void setupFilterButtons() {
        String[] filters = {"All", "Football", "Swimming", "Yoga", "Cricket"};

        for (String filter : filters) {
            Button btn = new Button(getContext());
            btn.setText(filter);
            btn.setAllCaps(false);
            btn.setTextColor(Color.WHITE);
            btn.setBackgroundResource(R.drawable.filter_button_background);
            btn.setPadding(24, 8, 24, 8);

            btn.setOnClickListener(v -> filterClasses(filter.equals("All") ? "" : filter));

            layoutFilters.addView(btn);
        }
    }

    private void bookClass(String selectedItem) {
        int userId = SessionManager.getUserId(getContext());

        // Strip rating and category
        String[] mainParts = selectedItem.split("★")[0].split(" \\(");
        String className = mainParts[0].trim();

        Cursor classCursor = dbHelper.getClassByName(className);
        if (classCursor != null && classCursor.moveToFirst()) {
            String classCategory = classCursor.getString(classCursor.getColumnIndexOrThrow(DatabaseHelper.CLASS_CATEGORY));

            // Mock time slots
            String[] timeSlots = {"08:00 AM", "09:00 AM", "10:00 AM", "05:00 PM", "06:30 PM"};

            new AlertDialog.Builder(getContext())
                    .setTitle("Select Time Slot")
                    .setItems(timeSlots, (dialog, which) -> {
                        String selectedTime = timeSlots[which];
                        boolean booked = dbHelper.addBooking(userId, className, selectedTime, classCategory);
                        if (booked) {
                            Toast.makeText(getContext(), "Booked at " + selectedTime, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Booking failed", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();

            classCursor.close();
        } else {
            Toast.makeText(getContext(), "Class not found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showReviewsDialog(String className) {
        List<String> reviews = dbHelper.getReviewsForClass(className);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Reviews for " + className);

        if (reviews.isEmpty()) {
            builder.setMessage("No reviews yet for this class.");
        } else {
            StringBuilder reviewList = new StringBuilder();
            for (String r : reviews) {
                reviewList.append("• ").append(r).append("\n\n");
            }
            builder.setMessage(reviewList.toString());
        }

        builder.setPositiveButton("Close", null);
        builder.show();
    }

}
